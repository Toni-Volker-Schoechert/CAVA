"""
Zuletzt editiert: 2026-04-04
Modulname: config
Maintainer: Toni Schoechert

Modulbeschreibung:
    Zentrale Projektkonfiguration.

    Ziel dieses aufgeräumten Stands:
    - gemeinsame Infrastruktur beibehalten
      (data_loader, roi, visualizer, debug, export)
    - zwei klassische Verfahren klar trennen
    - beide Verfahren leicht gegeneinander testbar machen
    - spätere Erweiterung, z. B. mit U-Net, vorbereiten

Aktuelle Verfahren:
    - canny_simple:
        einfacher Kantenansatz ohne Endpunkt-Logik
    - chan_vese:
        klassischer regionsbasierter Ansatz ohne neuronale Netze
        und ohne globalen Otsu-Schwellwert
"""

from pathlib import Path


CONFIG = {
    "method": {
        # Aktive Methode:
        # - "canny_simple"
        # - "chan_vese"
        "name": "chan_vese",
    },
    "window_names": {
        "roi_selection": "Polygon-ROI auswählen",
        "final_overlay": "Ergebnis",
        "debug_source": "Debug - Source Image",
        "debug_normalized": "Debug - Normalized Image",
        "debug_preprocess": "Debug - Preprocess",
        "debug_overlay": "Debug - Overlay",
        "method_debug": {
            # Canny-Methode
            "threshold_roi": "Debug - Threshold ROI",
            "canny_input": "Debug - Canny Input",
            "scharr_magnitude": "Debug - Scharr Magnitude",
            "raw_edges": "Debug - Raw Edges",
            "masked_raw_edges": "Debug - Masked Raw Edges",
            "refined_edges": "Debug - Refined Edges",
            "barrier": "Debug - Barrier",
            "free_regions": "Debug - Free Regions",
            "region_analysis": "Debug - Region Analysis",
            # Chan-Vese-Methode
            "region_input": "Debug - Region Input",
            "crop_roi": "Debug - Crop ROI",
            "initial_mask": "Debug - Initial Mask",
            "chan_vese_raw": "Debug - Chan-Vese Raw",
            "chan_vese_inverse": "Debug - Chan-Vese Inverse",
            "cleaned_mask": "Debug - Cleaned Mask",
            "cleaned_inverse": "Debug - Cleaned Inverse",
        },
    },
    "preprocessing": {
        # Wahl des Helligkeitskanals.
        # "gray" | "lab_l"
        "luminance_mode": "lab_l",

        # Optionale lokale Hintergrundnormalisierung.
        # Hilft oft mehr als aggressive Kontrastverstärkung,
        # wenn langsame Beleuchtungsschwankungen das Bild dominieren.
        "use_local_background_normalization": True,
        "background_normalization_sigma": 10.0,

        # Glättung vor den eigentlichen Verfahren.
        # "none" | "gaussian" | "bilateral"
        "filter_mode": "bilateral",
        "gaussian_kernel_size": (5, 5),
        "gaussian_sigma": 0,
        "bilateral_d": 7,
        "bilateral_sigma_color": 40,
        "bilateral_sigma_space": 40,

        # Optionale milde lokale Kontrastverstärkung.
        # Für Canny nur vorsichtig einsetzen und immer gegen
        # die Variante ohne CLAHE vergleichen.
        "use_clahe": True,
        "clahe_clip_limit": 3.0,
        "clahe_tile_grid_size": (16, 16),
    },
    "methods": {
        "canny_simple": {
            # Canny-Schwellenbestimmung.
            "threshold_roi_erosion_kernel_size": 15,
            "canny_mode": "gradient_quantiles",
            "canny_threshold_1": 30,
            "canny_threshold_2": 90,
            "canny_gradient_q_low": 0.20,
            "canny_gradient_q_high": 0.60,
            "canny_use_l2gradient": True,
            "canny_aperture_size": 3,

            # Moderate Kanten-Nachbearbeitung.
            "post_remove_small_components": True,
            "post_min_component_size": 100,
            "post_close_kernel_size": 10,
            "post_close_iterations": 1,
            "post_dilate_iterations": 0,

            # Regionensuche aus der Kantenbarriere.
            "barrier_dilate_iterations": 3,
            "min_contour_area_mode": "relative",
            "min_contour_area_px2": 50.0,
            "min_contour_area_factor": 0.001,
        },
        "chan_vese": {
            # Eingabebild für die regionsbasierte Suche.
            # True: normalisierte Version verwenden
            # False: direkt vorverarbeitetes Bild verwenden
            "use_normalized_image": True,
            "pre_blur_kernel_size": 5,

            # Chan-Vese arbeitet auf einem Crop um die ROI.
            "crop_padding_px": 10,

            # Initialisierung der Startfläche.
            # Sinnvolle Werte: "disk", "small disk", "checkerboard"
            "init_level_set": "disk",

            # Wichtige Chan-Vese-Parameter:
            # mu: Glattheit der Kontur
            # lambda1 / lambda2: Gewichtung innen / außen
            # tol: Abbruchschwelle
            # max_num_iter: maximale Iterationen
            # dt: Schrittweite
            "mu": 0.25,
            "lambda1": 1.0,
            "lambda2": 1.0,
            "tol": 1e-3,
            "max_num_iter": 250,
            "dt": 0.5,

            # Nachbearbeitung der resultierenden Maske.
            "remove_small_components": True,
            "min_component_size": 40,
            "open_kernel_size": 3,
            "close_kernel_size": 7,
            "close_iterations": 2,
            "fill_holes": True,

            # Mindestfläche der finalen Öffnung.
            "min_contour_area_mode": "relative",
            "min_contour_area_px2": 50.0,
            "min_contour_area_factor": 0.001,
        },
    },
    "visualization": {
        "wait_key_ms_image": 0,
        "wait_key_ms_video": 30,
    },
    "debug": {
        "enabled": True,
        "print_messages": True,
        "show_source_image": True,
        "show_normalized_image": True,
        "show_preprocess": True,
        "show_method_debug_images": True,
        "show_overlay": True,
        "show_final_result_when_not_debug": True,
    },
    "export": {
        "output_dir": Path("outputs"),
        "csv_filename": "results.csv",
    },
}
